<!DOCTYPE html>
<html lang="fr">

	<head>
        <meta charset="utf-8">
        <title> Premier script </title>

	</head>

    <body>

        <h1> Bienvenue dans votre espace membre </h1>

          
           <form method="post" action=../controleurs/deconnexion.php>
            </br>
            <label class=pouvez> Vous pouvez : </label>
            </br></br>

            <input type="submit" name="connecter" id="connecter" value="Modifier votre mot de passe"></br></br>
            <input type="submit" name="deconnecter" id="deconnecter" value=" Vous déconnecter"></br>

        </form>
    </body>
</html>
